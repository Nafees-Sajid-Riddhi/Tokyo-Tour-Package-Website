<?php 
   session_start();

   include("config.php");
   if(!isset($_SESSION['valid'])){
    header("Location: index.php");
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles4.css">
    <title>Tokyo Trip Itinerary</title>
    <style>
        
        #inclusions li,
        #exclusions li,
        #hotels li,
        h3,
        a {
            color:black;
        }
    </style>
</head>

<body>
       <header>
        <div class="header-left">
            <h1>Pheew ✈︎</h1>
        </div>
        <div class="header-right">
            <?php 
            $id = $_SESSION['id'];
            $query = mysqli_query($con,"SELECT*FROM users WHERE Id=$id");

            while($result = mysqli_fetch_assoc($query)){
                $res_Uname = $result['Username'];
                $res_Email = $result['Email'];
                $res_Phone = $result['Phone'];
                $res_Age = $result['Age'];
                $res_id = $result['Id'];
            }
            
             echo "<button class='btn edit-btn' onclick=\"window.location.href='edit.php?Id=$res_id'\">Edit Profile</button>";
            ?><a href="logout.php"><button class="btn logout-btn">Log Out</button></a>
	    </header>
    <nav>
        <ul>
            <li><a href="home2.php">Home</a></li>
            <li><a href="attraction.php">Attraction</a></li>
            <li><a href="package.php">Package</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </nav>
<div class="box1">
<h1 style="text-align:center;">Package 1: Tokyo</h1>
<section id="inclusions">
    <h3>Inclusions</h3>
    <ul>
        <li> Roundtrip Airfare</li>
        <li> Roundtrip Airport Transfers</li>
        <li> Travel Insurance</li>
        <li> Visa Fee</li>
    </ul>
</section>

<section id="exclusions">
    <h3>Exclusions</h3>
    <ul>
        <li> Tour guide tipping</li>
        <li> Personal charge at hotel (phone call, mini bar, laundry, and others)</li>
        <li> Personal expenses</li>
        <li> Optional tour</li>
    </ul>
</section>

<section id="hotels">
    <h3>Hotels</h3>
    <ul>
        <li><a href="https://www.daiwaroynet.jp/en/">Daiwa Roynet Hotels</a></li>
        <li><a href="https://www.okura-nikko.com/japan/urayasu/hotel-okura-tokyo-bay/?campaign=CA003669&campaignb=&d=30d-xppc&partner=FB-PACK-PPC-15&campaignId=653276609|29827469501|kwd-kwd-116487492079|CA003669||9072870&device=c&network=google&camefrom=g&gclid=Cj0KCQiAjMKqBhCgARIsAPDgWlz3h-HdCEyvrnt27g713gtXTlK6V-r56UKfmNmXWYnvjKtTC3hCfEYaAtYeEALw_wcB&clickid=Cj0KCQiAjMKqBhCgARIsAPDgWlz3h-HdCEyvrnt27g713gtXTlK6V-r56UKfmNmXWYnvjKtTC3hCfEYaAtYeEALw_wcB">Hotel Okura Tokyo Bay</a></li>
        <li><a href="https://www.kaneyamaen.com/eng/">Hotel Kaneyamaen & Bessho SASA</a></li>
    </ul>
</section>
<section id="day">
        <h3>Itinerary:</h3>

            <div class="day">
                <h4>DAY 01</h4>
                <ul>
                    <li>Meet at the airport</li>
                    <li>Transfer and check-in Hotel</li>
                    <li>Free at your own leisure</li>
                    <li class="hotel">Hotel: Daiwa Roynet Hotels</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 02</h4>
                <ul>
                    <li>Visit Asakusa</li>
                    <li>Experiencing Kimono</li>
                    <li>Visit Tokyo Skytree</li>
                    <li>Visit Sumida River</li>
                    <li>Visit Roppongi</li>
                    <li class="hotel">Hotel: Daiwa Roynet Hotels</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 03</h4>
                <ul>
                    <li>Visit Shinjuku Gyoen National Garden</li>
                    <li>Visit Shibuya Sky</li>
                    <li>Visit Meiji Jingu</li>
                    <li>Visit Kabukicho</li>
                    <li class="hotel">Hotel: Daiwa Roynet Hotels</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 04</h4>
                <ul>
                    <li>Visit Tsukiji Outer Market</li>
                    <li>Visit Akihabara Electric Town</li>
                    <li>Visit Ameyoko</li>
                    <li>Visit Tokyo National Museum</li>
                    <li class="hotel">Hotel: Daiwa Roynet Hotels</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 05</h4>
                <ul>
                    <li>Visit Ginza</li>
                    <li>Visit Imperial Palace (Photo Shop)</li>
                    <li>Visit Ueno Park</li>
                    <li>Visit Ghibli Museum</li>
                    <li>Visit Tokyo Tower</li>
                    <li class="hotel">Hotel: Daiwa Roynet Hotels</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 06</h4>
                <ul>
                    <li>Visit Disneyland</li>
                    <li class="hotel">Hotel: Hotel Okura Tokyo Bay</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 07</h4>
                <ul>
                    <li>Visit Fujikawaguchiko</li>
                    <li>Visit Oshino Hakkai</li>
                    <li>Visit Sky Ladder Town</li>
                    <li>Visit Sengen Shrine</li>
                    <li class="hotel">Hotel: Hotel Kaneyamaen & Bessho SASA</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 08</h4>
                <ul>
                    <li>Visit Lake Ashi</li>
                    <li>Visit Owakudani</li>
                    <li>Visit Kuzuryu Shrine</li>
                    <li class="hotel">Hotel: Hotel Kaneyamaen & Bessho SASA</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 09</h4>
                <ul>
                    <li>Visit Enoshima</li>
                    <li>Visit Kamakurakoko-Mae Station</li>
                    <li>Visit Kotoku-in</li>
                    <li>Visit Shichirigahama Beach</li>
                    <li class="hotel">Hotel: Hotel Kaneyamaen & Bessho SASA</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 10</h4>
                <ul>
                    <li>Transfer to airport</li>
                </ul>
            </div>
    </tr>
</table>
   </section>
<table>
    <tr>
             <ul> <h3>Special Remarks</h3>
                    <li> Minimum of 10 participants</li>
                    <li> Arrival/Departure Airports: For arrivals at Narita (NRT) or Haneda (HND) airport.</li>
                    <li> Meal Requests: Vegetarian, halal or special meals can be arranged.</li>
                    <li> Subject to be change according to changes in cost of operating or number of participants.</li>
            </ul>
   
    </tr>
</table>

<table>
    <tr>
            <ol><h3>Terms and Conditions</h3>
                    <li> Non-refundable RM600 per person to reserve. Upon acknowledgement of deposit receipt, booking is considered confirmed and final. Cancellation can no longer be processed.</li>
                    <li> Full payment must be settled within 60 days before the departure date. As the deadline for payment is already stated. The company reserves the right to cancel the booking without prior notice. Deposit will be forfeited.</li>
                    <li> Visa is applied 90 days before the departure date. In case denied, 50% of the guaranteed deposit amount can be refunded 30 days before the departure date. Late request for refund leads to forfeited deposit.</li>
                    <li> Standard check-in time 12.00pm, Standard check-out time 12.00pm.</li>
            </ol>
    </tr>
</table>
</div>
    <footer>
    <div class="footer-section">
        <h1>Office Hours</h1>
        <p>Monday - Friday: 9 AM - 6 PM</p>
        <h1>Contact Us</h1>
        <p><a href="https://instagram.com/cherry._.pj?igshid=NGVhN2U2NjQ0Yg==">Cherly ></a>
        <a href="https://instagram.com/__dannyyy06?igshid=NGVhN2U2NjQ0Yg==">Danny ></a>
        <a href="https://instagram.com/yulin.tan__?igshid=NGVhN2U2NjQ0Yg==">Yu Lin ></a>
        <a href="https://instagram.com/yoong._.hui?igshid=NGVhN2U2NjQ0Yg==">Yoong Hui ></a>
        <a href="https://instagram.com/qian_torng?igshid=NGVhN2U2NjQ0Yg==">Qian Torng ></a>
        <a href="https://instagram.com/mittens.zip?igshid=NGVhN2U2NjQ0Yg==">Nafeez ></a></p>
    </div>
    <div class="footer-section">
        <h1>Package</h1>
        <p><a href="attraction.php">Attraction</a>
        <a href="package.php">Package</a></p>
    </div>
    <div class="footer-section">
        <h1>Links</h1>
        <p><a href="https://www.japan.go.jp/">JapanGov - The Government of Japan ></a>
        <a href="https://www.mofa.go.jp/">Ministry of Foreign Affairs of Japan ></a>
        <a href="https://www.mofa.go.jp/about/emb_cons/mofaserv.html">Japanese Embassies and Consulates websites ></a>
        <a href="https://www.japan.travel/en/my/">Japan National Tourism Organization Web Site ></a>
        <a href="https://www.studyinjapan.go.jp/en/">Study in JAPAN ></a></p>
    </div>
</div>
</footer>
<footer class="rights">&copy; 2023 Pheew. All rights reserved.</footer>
</body>
</html>
