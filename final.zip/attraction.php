<?php 
   session_start();

   include("config.php");
   if(!isset($_SESSION['valid'])){
    header("Location: index.php");
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
  <style>
    table {
      width: 1200px;
      border-collapse: separate;
      border-spacing: 25px; 
      margin: auto;
      text-align: left;
      font-size: 20px;
     }
        .welcome p{
            font-weight: normal; 
    	    color: #FFF;
    	    text-decoration: none;
    	    font-size: 20px;
            text-align: right;
            margin: 10px 1px;
    	}
         .btn {
            height: 35px;
 	    background: rgba(76,68,182,0.808);
   	    border: 0;
   	    border-radius: 5px;
   	    color: #fff;
   	    font-size: 15px;
    	    cursor: pointer;
    	    transition: all .3s;
    	    margin-top: 10px;
    	    padding: 0px 10px;
         }
        .btn:hover {
           opacity: 0.82;
        }
    #table1 {
      width: 800px;
    }
    th, td {
      padding: 10px; 
      background-color: rgba(255, 255, 255, 0.5);
      border: 0px solid black; 
      vertical-align: top;  
    }
    body {
    background: linear-gradient(to bottom, #4E7AF9,#a0d2eb,#9df9ef,#edf756,#ffa8B6,#FC1E1E);                     
    }
  </style>
    <title>Pheew - Travel and Tourism</title>
</head>
<body>
    <header>
        <div class="header-left">
            <h1>Pheew ✈︎</h1>
        </div>
        <div class="header-right">
            <?php 
            $id = $_SESSION['id'];
            $query = mysqli_query($con,"SELECT*FROM users WHERE Id=$id");

            while($result = mysqli_fetch_assoc($query)){
                $res_Uname = $result['Username'];
                $res_Email = $result['Email'];
                $res_Phone = $result['Phone'];
                $res_Age = $result['Age'];
                $res_id = $result['Id'];
            }
            
             echo "<button class='btn edit-btn' onclick=\"window.location.href='edit.php?Id=$res_id'\">Edit Profile</button>";
            ?><a href="logout.php"><button class="btn logout-btn">Log Out</button></a>
	    </header>

    <nav>
        <ul>
            <li><a href="home2.php">Home</a></li>
            <li><a href="attraction.php">Attraction</a></li>
            <li><a href="package.php">Package</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </nav>
<body>

<table id="table1">
  
  <tr>
    <th colspan="2">Tokyo attraction <br><img align= "center" src="tokyo.jpg" width="800" height="450"><br>Tokyo, Japan's dynamic capital, is a captivating blend of tradition and cutting-edge innovation. Tokyo's diverse neighborhoods, exquisite cuisine, and cultural richness invite exploration.</th>
  </tr>
</table>

<table>
  <tr>
    <td><b>Sensoji Temple </b> <br> <img src="3.jpg" width="400" height="250"><br> Sensoji Temple, Tokyo's oldest and most significant, captivates visitors with its rich history and iconic features, including a reconstructed main hall and a towering 55-meter Pagoda. The temple is accessible through the bustling Nakamise Dori shopping street, leading to the awe-inspiring Kaminarimon or "Thunder Gate," adorned with the world's largest paper lantern.</td>
    <td><b>Tokyo skytree</b> <br><img src="Skytree.jpg" width="400" height="250"><br> Tokyo Skytree, towering at 634 meters, is not just Tokyo's tallest structure but also the world's tallest tower, second only to Dubai's Burj Khalifa. This multifunctional complex includes a broadcasting tower, restaurant, and observation deck, surrounded by a vibrant hub of shopping and dining, making it a central attraction in Tokyo.</td>
  

<td><b>Sumida river</b> <br>
<img src="Sumida.jpg"  width="400 height="250">
<br> 
Countless cherry trees burst into bloom along the Sumida River, reaching the peak of their beauty between March and April. Tokyo's riverside avenues transform into a stunning spectacle, with illuminated blossoms creating a unique experience, especially when enjoying the view from a water bus.</td>
  </tr>


<tr>
<td><b>Shinjuku Gyoen </b> 
<br> <img " src="garden2.jpg" width="400" height="250">
<br> Shinjuku Gyoen stands as one of Tokyo's largest and most frequented parks, situated just a brief stroll from Shinjuku Station. Its expansive lawns, winding pathways, and serene surroundings offer a peaceful retreat from the bustling urban hub that surrounds it. During spring, Shinjuku Gyoen transforms into one of the city's premier locations to witness the beauty of cherry blossoms.</td>

<td>
<b>Owakudani</b> 
<br><img src="007.jpeg" width="400" height="250"><br> 
Accessible via the picturesque Hakone Ropeway, visitors can take a cable car to Owakudani Station at the summit and revel in the breathtaking view of Mount Fuji during the ascent.
A unique specialty of the region is the "kuro-tamago," or "black egg." These eggs derive their color from being boiled in the sulfur and iron-rich hot springs of Owakudani, and folklore suggests that consuming them can contribute to longevity.
</td>
  

<td>
<b>Disneyland</b> 
<br><img " src="002.jpg" width="400 height="250">
<br> 
Tokyo Disneyland consists of seven zones: Adventureland, Westernland, Fantasyland, Tomorrowland, Critter Country, Mickey's Toontown, and the exclusive World Bazaar. It offers popular rides like Space Mountain, Pirates of the Caribbean, Big Thunder Mountain, and Haunted Mansion, as well as immersive experiences such as Star Tours: The Adventures Continue, Monsters, Inc. Ride & Go Seek!, and Pooh's Hunny Hunt.</td>  
</tr>

<tr>
<td><b>Oshino hakkai </b> 
<br> <img " src="003.jpg" width="400" height="250">
<br> Oshino Hakkai features eight ponds fed by an underground reservoir from Mt. Fuji.  These mineral-rich ponds are interconnected by pathways and bridges, contributing to the Mt. Fuji World Heritage Site. Throughout the year, the view of Mt. Fuji from Oshino Hakkai is stunning and recognized as one of the top 100 views of Mt. Fuji in Kanto. </td>

<td>
<b>Sengen shrine</b> 
<br><img src="004.jpeg" width="400" height="250"><br> 
Fujiyoshida Sengen Shrine symbolizes the people's attempt to pacify the angered gods thought to be responsible for Mount Fuji's eruption. The path to the shrine is lined with ancient cedar trees and stone lanterns, leading to a prominent red pagoda. In the past, Kawaguchi Sengen Shrine served as a popular starting point for those ascending Mount Fuji from the north, with the trailhead located behind the shrine's main hall.
</td>
  

<td>
<b>Ueno park</b> 
<br><img " src="005.jpg" width="400 height="250">
<br> 
Ueno Park in central Tokyo is an expansive public park with historical roots, initially part of the temple grounds. The park stands out as one of the vibrant and favored cherry blossom destinations in Tokyo, adorned with over 1000 cherry trees along its main pathway, attracting large crowds for hanami gatherings from late March to early April.</td> 
</tr>
</table>

<table id="table1">
  
  <tr>
    <th colspan="2">Osaka attraction <br><img align= "center" src="102.jpg" width="800" height="450"><br> Osaka, the second-largest metropolitan area in Japan following Tokyo, is Japan's lively metropolis. The diverse districts, delectable cuisine, and cultural allure of Osaka beckon exploration, creating a dynamic and captivating experience.</th>
  </tr>
</table>

<table>
  <tr>
    <td><b>Dotunbori  </b> <br> <img src="101.jpeg" width="400" height="250"><br> Dotonbori, lining its iconic canal, epitomizes the lively nightlife of Osaka's Chuo ward in the Namba district. Boasting neon lights, street food delights, nostalgic vibes, nightclubs, shops, and bars, the area is renowned for "kuidaore," a concept encouraging indulgence in lavish food experiences. Immerse yourself responsibly in the lively spirit of "kuidaore" by exploring this celebrated entertainment hub, captivated by its infectious energy.</td>

    <td><b>Kuromon Ichiba Market </b> <br><img src="103.jpg" width="400" height="250"><br> Kuromon Ichiba Market, a bustling 580-meter covered market in Osaka's Chuo Ward, dubbed "Osaka's kitchen," serves as a major supplier for locals and chefs. Known for its abundance of fresh seafood, it has become a popular tourist destination, attracting substantial crowds, with an average of 23,000 daily visitors in 2015. The market's unique charm lies in its stalls not only offering fresh produce but also preparing and serving food on-site, creating an ideal setting for leisurely exploration and indulging in a diverse array of delicious offerings.</td>
  

<td><b>minoo park </b> <br>
<img src="104.jpeg"  width="400 height="250">
<br> 
Minoo Park, on the outskirts of Osaka, north of the city, is a wooded valley renowned for its stunning autumn colors, making it a prime spot in the Kansai Region. The vibrant foliage, distinct from temples and gardens, reaches its peak in late November. Serving as the closest natural recreation area to Osaka, the park offers a three-kilometer hiking trail along the Minoo River.</td>
  </tr>

  <tr>
  <td><b>Universal Studios Japan (USJ) </b> <br>
<img src="105.jpg"  width="400 height="250">
<br> Universal Studios Japan (USJ) in Osaka stands as the renowned theme park in the Kansai region and one of four Universal Studios theme parks globally. As the initial Universal Studios-branded theme park established in Asia, it commenced operations in March 2001 and now ranks as the second most frequented amusement park in Japan following the Tokyo Disney Resort.</td>
  </tr>
</table>

<table id="table1">
  
  <tr>
    <th colspan="2">Kyoto attraction <br><img align= "center" src="106.jpg" width="800" height="450"><br> Kyoto embodies the quintessential image that many travelers associate with Japan. Serving as the nation's spiritual core and cultural essence, the ancient capital boasts a range of attractions, including World Heritage temples and shrines, time-honored gardens, longstanding shops and restaurants, and charming backstreets.</th>
  </tr>
</table>

<table>
<tr>
    <td><b>
Kiyomizu-dera temple</b> <br> <img src="107.jpg" width="400" height="250"><br> Kiyomizu-dera, a renowned temple in Kyoto, boasts a remarkable platform positioned on a cliff, supported by 139 Zelkova pillars. Visitors, after paying respects at the altar, can enjoy panoramic views, including a nearby pagoda, downtown Kyoto, and events like Sumo wrestling, concerts, and traditional performances held on the expansive platform over the years.</td>

    <td><b>Sannezaka  </b> <br><img src="108.jpg" width="400" height="250"><br> The timeless Sannenzaka cobblestone streets, adorned with historic Japanese structures, embody Kyoto's essence and serve as a pivotal segment of the popular sightseeing route around Kiyomizu Temple. Ascending the gentle slope, you can immerse yourself in the Kyoto atmosphere, with Kiyomizu's three-tiered pagoda overlooking private residences and scattered temples. Stretching for about 100 meters, Sannenzaka, near Kodaiji Temple and Yasaka Shrine, offers a lunchtime visit with an abundance of nearby restaurants.</td>
  

<td><b>Arashiyama park </b> <br>
<img src="109.jpg"  width="400 height="250">
<br> 
Arashiyama park nestled at the foot of the "Storm Mountains" in northern Kyoto, the famous Arashiyama Bamboo Forest provides a serene nature retreat in Japan, accessible at all hours with free entry. Explore the nearby Arashiyama district, known for unique cormorant bird fishing techniques.</td>
  </tr>
</table>

<table id="table1">
  
  <tr>
    <th colspan="2">Hokkaido  attraction <br><img align= "center" src="110.jpg" width="800" height="450"><br> Hokkaido, Japan's second-largest main island, is located at the northernmost part of the country, closer to Russia than Tokyo. Renowned for its expansive mountains, abundant snowfall, and vast open roads beneath a wide sky, Hokkaido is increasingly attracting international visitors seeking experiences such as skiing, snowboarding, hiking, and enjoying hot springs.</th>
  </tr>
</table>

<table>
<tr>
    <td><b>Otaru Canal </b> <br> <img src="111.jpg" width="400" height="250"><br> The Otaru Canal stands as an iconic attraction among the renowned sights in Hokkaido. In its heyday, it served as the primary distribution hub of the region, boasting a population that exceeded even that of Sapporo. During this period, the canal played a crucial role in unloading ships through barges, extending the reach for goods distribution. As docks were later established, rendering the canal obsolete for its original purpose, plans were made to fill it with land. However, today it has transformed into a leisure spot for both locals and tourists, offering pleasant promenades illuminated by charming gas lamps along the riverbanks.</td>

    <td><b>Asahikawa zoo   </b> <br><img src="113.jpeg" width="400" height="250"><br> Asahiyama Zoo, located just beyond the heart of Asahikawa City, is a highly regarded zoological park. Its fame in Japan is attributed to its innovative "behavior display" approach, which highlights the natural ecology and behaviors of animals.Every day, numerous visitors, both local and international, flock to Asahiyama Zoo to witness the vibrant activities of its animals. It has become a preferred destination for many. Here are some recommendations for optimizing your visit to this popular zoo.</td>
  

<td><b>jigokudani monkey park  </b> <br>
<img src="114.jpg"  width="400 height="250">
<br> 
Nestled along the Yokoyugawa River at 850 meters elevation, Jigokudani Monkey Park faces a challenging environment with snow covering one-third of the year. The rugged cliffs and steaming hot springs contribute to its name, "Hell's Valley." Home to wild Japanese macaques, or snow monkeys, they descend from the mountains in pursuit of provided food. In winter, these monkeys seek warmth in the park's hot spring, creating a captivating spectacle of them enjoying the hot water amid falling snow, showcasing human-like behavior.</td>
  </tr>
</table>
     <footer>
    <div class="footer-section">
        <h1>Office Hours</h1>
        <p>Monday - Friday: 9 AM - 6 PM</p>
        <h1>Contact Us</h1>
        <p><a href="https://instagram.com/cherry._.pj?igshid=NGVhN2U2NjQ0Yg==">Cherly ></a>
        <a href="https://instagram.com/__dannyyy06?igshid=NGVhN2U2NjQ0Yg==">Danny ></a>
        <a href="https://instagram.com/yulin.tan__?igshid=NGVhN2U2NjQ0Yg==">Yu Lin ></a>
        <a href="https://instagram.com/yoong._.hui?igshid=NGVhN2U2NjQ0Yg==">Yoong Hui ></a>
        <a href="https://instagram.com/qian_torng?igshid=NGVhN2U2NjQ0Yg==">Qian Torng ></a>
        <a href="https://instagram.com/mittens.zip?igshid=NGVhN2U2NjQ0Yg==">Nafeez ></a></p>
    </div>
    <div class="footer-section">
        <h1>Package</h1>
        <p><a href="attraction.php">Attraction</a>
        <a href="package.php">Package</a></p>
    </div>
    <div class="footer-section">
        <h1>Links</h1>
        <p><a href="https://www.japan.go.jp/">JapanGov - The Government of Japan ></a>
        <a href="https://www.mofa.go.jp/">Ministry of Foreign Affairs of Japan ></a>
        <a href="https://www.mofa.go.jp/about/emb_cons/mofaserv.html">Japanese Embassies and Consulates websites ></a>
        <a href="https://www.japan.travel/en/my/">Japan National Tourism Organization Web Site ></a>
        <a href="https://www.studyinjapan.go.jp/en/">Study in JAPAN ></a></p>
    </div>
</footer>
<footer class="rights">&copy; 2023 Pheew. All rights reserved.</footer>
</body>
</html>