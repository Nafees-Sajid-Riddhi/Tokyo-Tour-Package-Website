<?php
 
 $con = mysqli_connect("localhost","root","","booking") or die("Couldn't connect");

?>