<?php 
   session_start();

   include("config.php");
   if(!isset($_SESSION['valid'])){
    header("Location: index.php");
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tour Packages</title>
    <link rel="stylesheet" href="styles4.css">
</head>
<body>

    <header>
        <div class="header-left">
            <h1>Pheew ✈︎</h1>
        </div>
        <div class="header-right">
            <?php 
            $id = $_SESSION['id'];
            $query = mysqli_query($con,"SELECT*FROM users WHERE Id=$id");

            while($result = mysqli_fetch_assoc($query)){
                $res_Uname = $result['Username'];
                $res_Email = $result['Email'];
                $res_Phone = $result['Phone'];
                $res_Age = $result['Age'];
                $res_id = $result['Id'];
            }
            
             echo "<button class='btn edit-btn' onclick=\"window.location.href='edit.php?Id=$res_id'\">Edit Profile</button>";
            ?><a href="logout.php"><button class="btn logout-btn">Log Out</button></a>
	    </header>
    <nav>
        <ul>
            <li><a href="home2.php">Home</a></li>
            <li><a href="attraction.php">Attraction</a></li>
            <li><a href="package.php">Package</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </nav>

	<div class="header-image-container">
            <img src="collage.jpg" alt="Header Image">
        </div>

<div class="box">

    <h1>Welcome to the Japan Tour Packages!</h1>
    <p>Discover the beauty of Japan with our exclusive tour packages</p>
<div class="container">
        <a href="tokyotrip.php" class="option">
            <div class="image-container">
                <img src="tokyo2.jpg" alt="Tokyo Image">
            </div>
            <div class="option-content">
                <h2>Package 1: Tokyo</h2>
                <p>10 DAYS 9 NIGHTS ALL IN PACKAGE</p>
                <p>AIRFARE - HOTELS - TOURS - MEALS</p>
                <p style="color:red";>RM<del>16760</del>16560</p>
            </div>
        </a>
</div>
<div class="container">
        <a href="osakapage.php" class="option">
            <div class="image-container">
                <img src="osaka_kyoto_image.jpg" alt="Osaka & Kyoto Image">
            </div>
            <div class="option-content">
                <h2>Package 2: Osaka & Kyoto</h2>
                <p>10 DAYS 9 NIGHTS ALL IN PACKAGE</p>
                <p>AIRFARE - HOTELS - TOURS - MEALS</p>
                <p style="color:red";>RM<del>16760</del>16560</p>
            </div>
        </a></div>
<div class="container">
        <a href="hokkaidopage.php" class="option">
            <div class="image-container">
                <img src="hokkaido_image.jpg" alt="Hokkaido Image">
            </div>
            <div class="option-content">
                <h2>Package 3: Hokkaido</h2>
                <p>10 DAYS 9 NIGHTS ALL IN PACKAGE</p>
                <p>AIRFARE - HOTELS - TOURS - MEALS</p>
                <p style="color:red";>RM<del>16760</del>16560</p>
            </div>
        </a>
</div>
    </div>
</div>
     <footer>
    <div class="footer-section">
        <h1>Office Hours</h1>
        <p>Monday - Friday: 9 AM - 6 PM</p>
        <h1>Contact Us</h1>
        <p><a href="https://instagram.com/cherry._.pj?igshid=NGVhN2U2NjQ0Yg==">Cherly ></a>
        <a href="https://instagram.com/__dannyyy06?igshid=NGVhN2U2NjQ0Yg==">Danny ></a>
        <a href="https://instagram.com/yulin.tan__?igshid=NGVhN2U2NjQ0Yg==">Yu Lin ></a>
        <a href="https://instagram.com/yoong._.hui?igshid=NGVhN2U2NjQ0Yg==">Yoong Hui ></a>
        <a href="https://instagram.com/qian_torng?igshid=NGVhN2U2NjQ0Yg==">Qian Torng ></a>
        <a href="https://instagram.com/mittens.zip?igshid=NGVhN2U2NjQ0Yg==">Nafeez ></a></p>
    </div>
    <div class="footer-section">
        <h1>Package</h1>
        <p><a href="attraction.php">Attraction</a>
        <a href="package.php">Package</a></p>
    </div>
    <div class="footer-section">
        <h1>Links</h1>
        <p><a href="https://www.japan.go.jp/">JapanGov - The Government of Japan ></a>
        <a href="https://www.mofa.go.jp/">Ministry of Foreign Affairs of Japan ></a>
        <a href="https://www.mofa.go.jp/about/emb_cons/mofaserv.html">Japanese Embassies and Consulates websites ></a>
        <a href="https://www.japan.travel/en/my/">Japan National Tourism Organization Web Site ></a>
        <a href="https://www.studyinjapan.go.jp/en/">Study in JAPAN ></a></p>
    </div>
</footer>
<footer class="rights">&copy; 2023 Pheew. All rights reserved.</footer>
</body>
</html>

