<?php 
   session_start();

   include("config.php");
   if(!isset($_SESSION['valid'])){
    header("Location: index.php");
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            margin: 0;
            padding: 0;
        }
        .main-content {
            padding: 20px;
            margin: 10px;
            margin-right: 10px;
            border-radius: 10px;
            color: #ffffff;
        }
        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
         .btn {
            height: 35px;
 	    background: rgba(76,68,182,0.808);
   	    border: 0;
   	    border-radius: 5px;
   	    color: #fff;
   	    font-size: 15px;
    	    cursor: pointer;
    	    transition: all .3s;
    	    margin-top: 10px;
    	    padding: 0px 10px;
            text-decoration: none;
    	}
        .btn:hover {
           opacity: 0.82;
        }
        .option {
            text-decoration: none;
            color: #ffffff;
            width: 100%;
            height: 500px;
            margin: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            overflow: hidden;
            transition: box-shadow 0.3s ease;
            background-image: url('japan.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat; 
        }
        .option:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .image-container {
            width: 100%;
            height: 200px;
            overflow: hidden;
        }
        .image-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }
        .option-content {
            padding: 20px;
            text-align: justify;
            color: #ffffff;
            text-shadow: 2px 2px 4px rgba(255, 255, 255, 0.8);
        }
        h2 {
            margin-bottom: 10px;
            color: #ffffff;
            margin-right: 600px;
            font-size: 36px;
            margin-left: 20px;
        }
        p {
            margin-top: 40px;
            color: #ffffff;
            margin-right: 600px;
            font-size: 18px;
            font-weight: bold; 
            margin-left: 20px;
        }
        .container2 {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
        .option2 {
            text-decoration: none;
            color: #333;
            width: 100%;
            height: 500px;
            margin: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            overflow: hidden;
            transition: box-shadow 0.3s ease;
            background-image: url('japan2.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat; 
        }
        .option2:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .image-container2 {
            width: 100%;
            height: 200px;
            overflow: hidden;
        }
        .image-container2 img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }
        .option-content2 {
            padding: 20px;
            text-align: justify;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8); 
            margin-right: 400px;
            margin-left: 100px;
        }
        h3 {
            margin-bottom: 50px;
            color: #fff;
            margin-right: 600px;
            font-size: 36px;
        }
        p2 {
            margin-top: 40px;
            color: #fff;
            margin-right: 600px;
            font-size: 18px;
            line-height: 1.5; 
        }
        a2 {
            color: #007BFF;
            text-decoration: none;
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
       .container3 {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
        .option3 {
            text-decoration: none;
            color: #333;
            width: 100%;
            height: 500px;
            margin: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            overflow: hidden;
            transition: box-shadow 0.3s ease;
            background-image: url('japan3.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat; 
        }
        .option3:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .image-container3 {
            width: 100%;
            height: 200px;
            overflow: hidden;
        }
        .image-container3 img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }
        .option-content3 {
            padding: 20px;
            text-align: justify;
            margin-left: 600px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8); 
        }
        h4 {
            margin-bottom: 50px;
            color: #fff;
            font-size: 36px;
        }
        p3 {
            margin-top: 60px;
            color: #fff;
            margin-right: 0px;
            font-size: 18px;
            line-height: 1.5; 
        }

    </style>
    <title>Pheew - Travel and Tourism</title>
</head>
<body>
    <header>
        <div class="header-left">
            <h1>Pheew ✈︎</h1>
        </div>
        <div class="header-right">
            <?php 
            $id = $_SESSION['id'];
            $query = mysqli_query($con,"SELECT*FROM users WHERE Id=$id");

            while($result = mysqli_fetch_assoc($query)){
                $res_Uname = $result['Username'];
                $res_Email = $result['Email'];
                $res_Phone = $result['Phone'];
                $res_Age = $result['Age'];
                $res_id = $result['Id'];
            }
            
             echo "<button class='btn edit-btn' onclick=\"window.location.href='edit.php?Id=$res_id'\">Edit Profile</button>";
            ?><a href="logout.php"><button class="btn logout-btn">Log Out</button></a>
	    </header>

    <nav>
        <ul>
            <li><a href="home2.php">Home</a></li>
            <li><a href="attraction.php">Attraction</a></li>
            <li><a href="package.php">Package</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </nav>

    <section class="main-content">
    <div class="container">
        <a href="http://localhost/demo/web/index.php" class="option">
            <div class="option-content">
                <h2>Welcome to Pheew - Your Gateway to Japan!</h2>
                <p>Explore the beauty of Japan with Pheew, your premier travel and tourism company. We offer curated travel packages that guarantee an unforgettable experience. From ancient temples to modern metropolises, discover the wonders of Japan with us.</p>
            </div>
        </a>
    </div>
    </section>
    <section class="main-content">
    <div class="container2">
        <a href="attraction.html" class="option2">
            <div class="option-content2">
                <h3>Attraction</h3>
                <p2>Immerse yourself in the allure of Japan's mesmerizing attractions. From ancient landmarks to modern marvels, our curated selection promises an enriching experience. Explore the unique cultural tapestry that defines each attraction and make memories that last a lifetime.</p2>
            </div>
        </a>
    </div>
    </section>
    <section class="main-content">
    <div class="container3">
        <a href="package.html" class="option3">
            <div class="option-content3">
                <h4>Package</h4>
                <p3>Embark on an unforgettable journey with our exclusive travel packages. We offer meticulously crafted experiences that blend adventure, relaxation, and cultural immersion. Discover the beauty of Japan through our curated itineraries, designed to make your travel dreams a reality.</p3>
            </div>
        </a>
    </div>
    </section>
     <footer>
    <div class="footer-section">
        <h1>Office Hours</h1>
        <p>Monday - Friday: 9 AM - 6 PM</p>
        <h1>Contact Us</h1>
        <p><a href="https://instagram.com/cherry._.pj?igshid=NGVhN2U2NjQ0Yg==">Cherly ></a>
        <a href="https://instagram.com/__dannyyy06?igshid=NGVhN2U2NjQ0Yg==">Danny ></a>
        <a href="https://instagram.com/yulin.tan__?igshid=NGVhN2U2NjQ0Yg==">Yu Lin ></a>
        <a href="https://instagram.com/yoong._.hui?igshid=NGVhN2U2NjQ0Yg==">Yoong Hui ></a>
        <a href="https://instagram.com/qian_torng?igshid=NGVhN2U2NjQ0Yg==">Qian Torng ></a>
        <a href="https://instagram.com/mittens.zip?igshid=NGVhN2U2NjQ0Yg==">Nafeez ></a></p>
    </div>
    <div class="footer-section">
        <h1>Package</h1>
        <p><a href="attraction.php">Attraction</a>
        <a href="package.php">Package</a></p>
    </div>
    <div class="footer-section">
        <h1>Links</h1>
        <p><a href="https://www.japan.go.jp/">JapanGov - The Government of Japan ></a>
        <a href="https://www.mofa.go.jp/">Ministry of Foreign Affairs of Japan ></a>
        <a href="https://www.mofa.go.jp/about/emb_cons/mofaserv.html">Japanese Embassies and Consulates websites ></a>
        <a href="https://www.japan.travel/en/my/">Japan National Tourism Organization Web Site ></a>
        <a href="https://www.studyinjapan.go.jp/en/">Study in JAPAN ></a></p>
    </div>
   </footer>
<footer class="rights">&copy; 2023 Pheew. All rights reserved.</footer>
</body>
</html>
    