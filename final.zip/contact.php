<?php 
   session_start();

   include("config.php");
   if(!isset($_SESSION['valid'])){
    header("Location: index.php");
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - Pheew</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f8f8f8;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    header {
      background-color: #F3B2C9;
      color: #fff;
      padding: 15px 20px;
      display: flex;
      justify-content: space-between;
      align-items: right;
    }

    .header-left h1 {
      margin: 0;
      font-size: 24px;
    }

    .header-right  {
      color: #fff;
      text-decoration: none;
      font-size: 18px;
      text-align: right;
    }

nav {
    background-color: #fff;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 10px;
}

nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: space-around;
}

nav a {
    text-decoration: none;
    color: #000000;
    font-weight: bold;
    font-size: 16px;
    padding: 10px 30px;
    transition: color 0.3s ease-in-out;
}

nav a:hover {
    background-color: #F3B2C9;
   
}    
.top {
      background-image: url('contact us image.jpg'); 
      background-size: cover;
      background-position: center;
      color: #fff;
      padding: 100px 20px;
      text-align: center;
      position: relative;
      border: 3px solid #ff6ec7;
      border-radius: 5px;
      box-shadow: 0 0 10px 3px #ff6ec7;
      animation: glow 2s infinite alternate;
      opacity: 0.8; 
    }

    .top-image-container {
      width: 100%;
      height: 400px;
      max-width: 1600px;
      max-height: 200px;
      overflow: hidden;
      margin: 20px 0;
      position: relative;
      border: 3px solid #ff6ec7;
      border-radius: 5px;
      box-shadow: 0 0 10px 3px #ff6ec7;
      animation: glow 2s infinite alternate;
    }

    .top-image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 5px;
    }

    main {
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
    }

    section {
      width: 45%;
      margin: 20px 20px;
      padding: 20px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      box-sizing: border-box;
    }

    h2 {
      color: #ff6ec7;
    }

    label {
      display: block;
      margin-bottom: 8px;
      color: #555;
    }

    input,
    textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

   .btn1 {
            height: 35px;
 	    background: rgba(76,68,182,0.808);
   	    border: 0;
   	    border-radius: 5px;
   	    color: #fff;
   	    font-size: 15px;
    	    cursor: pointer;
    	    transition: all .3s;
    	    margin-top: 10px;
    	    padding: 0px 10px;
    }
    .btn1:hover {
      opacity: 0.82;
    }

    button {
      background-color: rgba(76,68,182,0.808);
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 15px;
      transition: all .3s;
    }

    button:hover {
      opacity: 0.82;
    }

  footer.rights{
      background-color: #F3B2C9; 
      color: #fff;
      text-align: center;
      padding: 10px;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

    .column {
      width: 45%;
      box-sizing: border-box;
    }

    .column pre {
      font-family: 'Arial', sans-serif;
    }

    .column pre span.phone {
      color: #ff6ec7;
    }
        footer {
            background-color: #89CFF0;
            color: #1d2951;
            text-align: center;
            bottom: 0;
            width: 100%;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            padding: 20px;
            font-weight: bold;
        }
        .footer-section {
            flex: 1;
            max-width: 300px;
        }
        .footer-section h1 {
            margin-bottom: 20px;
            text-align: left;
            color: #1d2951;
        }
        .footer-section p {
            margin: 0;
            text-align: left;
            color: #fff;
        }
        .footer-section a {
            display: block;
            margin-top: 10px;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            
        }
  </style>
</head>
<body>
    <header>
        <div class="header-left">
            <h1>Pheew ✈︎</h1>
        </div>
        <div class="header-right">
            <?php 
            $id = $_SESSION['id'];
            $query = mysqli_query($con,"SELECT*FROM users WHERE Id=$id");

            while($result = mysqli_fetch_assoc($query)){
                $res_Uname = $result['Username'];
                $res_Email = $result['Email'];
                $res_Phone = $result['Phone'];
                $res_Age = $result['Age'];
                $res_id = $result['Id'];
            }
            
             echo "<button class='btn edit-btn' onclick=\"window.location.href='edit.php?Id=$res_id'\">Edit Profile</button>";
            ?><a href="logout.php"><button class="btn logout-btn">Log Out</button></a>
	    </header>

    <nav>
        <ul>
            <li><a href="home2.php">Home</a></li>
            <li><a href="attraction.php">Attraction</a></li>
            <li><a href="package.php">Package</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </nav>
  <div class="top">
    <h1>Keep in Contact with <i>Pheew✈︎</i></h1>
  </div>

  <main>
    <section>
      <h2>Contact Us</h2>
      <p>We'd love to hear from you! Drop us a message if you have any questions or feedback about your Japan travel experience :)</p>

      <form id="contactForm">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="comment">Comment:</label>
        <textarea id="comment" name="comment" rows="6" required></textarea>

        <button type="submit">Submit</button>
      </form>
    </section>

    <section class="column">
      <h2>Our Contacts</h2>
      <pre>Address: No. 1, UCSI Heights, Jalan Puncak Menara Gading, 
               Taman Connaught, 56000 Cheras, 
               Wilayah Persekutuan Kuala Lumpur</pre>

      <pre>Email:     Pheew@gmail.com</pre>

      <pre>Phone: <span class="phone">012-2906789</span></pre>
    </section>
  </main>
     <footer>
    <div class="footer-section">
        <h1>Office Hours</h1>
        <p>Monday - Friday: 9 AM - 6 PM</p>
        <h1>Contact Us</h1>
        <p><a href="https://instagram.com/cherry._.pj?igshid=NGVhN2U2NjQ0Yg==">Cherly ></a>
        <a href="https://instagram.com/__dannyyy06?igshid=NGVhN2U2NjQ0Yg==">Danny ></a>
        <a href="https://instagram.com/yulin.tan__?igshid=NGVhN2U2NjQ0Yg==">Yu Lin ></a>
        <a href="https://instagram.com/yoong._.hui?igshid=NGVhN2U2NjQ0Yg==">Yoong Hui ></a>
        <a href="https://instagram.com/qian_torng?igshid=NGVhN2U2NjQ0Yg==">Qian Torng ></a>
        <a href="https://instagram.com/mittens.zip?igshid=NGVhN2U2NjQ0Yg==">Nafeez ></a></p>
    </div>
    <div class="footer-section">
        <h1>Package</h1>
        <p><a href="attraction.php">Attraction</a>
        <a href="package.php">Package</a></p>
    </div>
    <div class="footer-section">
        <h1>Links</h1>
        <p><a href="https://www.japan.go.jp/">JapanGov - The Government of Japan ></a>
        <a href="https://www.mofa.go.jp/">Ministry of Foreign Affairs of Japan ></a>
        <a href="https://www.mofa.go.jp/about/emb_cons/mofaserv.html">Japanese Embassies and Consulates websites ></a>
        <a href="https://www.japan.travel/en/my/">Japan National Tourism Organization Web Site ></a>
        <a href="https://www.studyinjapan.go.jp/en/">Study in JAPAN ></a></p>
    </div>
    </footer>
<footer class="rights">&copy; 2023 Pheew. All rights reserved.</footer>

<script>
        function submitForm() {
            var name = document.getElementById('name').value;
            var email = document.getElementById('email').value;
            var comment = document.getElementById('comment').value;

            // Perform basic validation
            if (name.trim() === '' || email.trim() === '' || comment.trim() === '') {
                alert('Please fill in all fields');
                return;
            }

            // You can perform additional validation or send the form data to a server here
            // For simplicity, we'll just display an alert with the form data
            alert('Name: ' + name + '\nEmail: ' + email + '\nComment: ' + comment);

            // Optionally, you can reset the form after submission
            document.getElementById('contactForm').reset();
        }
</script>
</body>
</html>