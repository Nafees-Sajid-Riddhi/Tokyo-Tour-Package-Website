<?php 
   session_start();

   include("config.php");
   if(!isset($_SESSION['valid'])){
    header("Location: index.php");
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles4.css">
    <title>Hokkaido Trip Itinerary</title>
    <style>
        
        #inclusions li,
        #exclusions li,
        #hotels li,
        h3,
        a {
            color: black;
        }
    </style>
</head>

<body>
    <header>
        <div class="header-left">
            <h1>Pheew ✈︎</h1>
        </div>
        <div class="header-right">
            <?php 
            $id = $_SESSION['id'];
            $query = mysqli_query($con,"SELECT*FROM users WHERE Id=$id");

            while($result = mysqli_fetch_assoc($query)){
                $res_Uname = $result['Username'];
                $res_Email = $result['Email'];
                $res_Phone = $result['Phone'];
                $res_Age = $result['Age'];
                $res_id = $result['Id'];
            }
            
             echo "<button class='btn edit-btn' onclick=\"window.location.href='edit.php?Id=$res_id'\">Edit Profile</button>";
            ?><a href="logout.php"><button class="btn logout-btn">Log Out</button></a>
	    </header>
    <nav>
        <ul>
            <li><a href="home2.php">Home</a></li>
            <li><a href="attraction.php">Attraction</a></li>
            <li><a href="package.php">Package</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </nav>
<div class="box1">
<div class="detail">
<h1 style="text-align:center;">Package 3: Hokkaido</h1>
    <section id="inclusions">
        <h3>Inclusions</h3>
        <ul>
            <li> Roundtrip Airfare</li>
            <li> Roundtrip Airport Transfers</li>
            <li> Travel Insurance</li>
            <li> Visa Fee</li>
        </ul>
    </section>

    <section id="exclusions">
        <h3>Exclusions</h3>
        <ul>
            <li> Tour guide tipping</li>
            <li> Personal charge at hotel (phone call, mini bar, laundry and others)</li>
            <li> Personal expenses</li>
            <li> Optional tour</li>
        </ul>
    </section>

    <section id="hotels">
        <h3>Hotels</h3>
        <ul>
            <li><a href="https://yu-rinkan.com/">Pipa no Yu Yurinkan</a></li>
            <li><a href="https://takimotokan.co.jp/en/">Dai-ichi Takimotokan</a></li>
        </ul>
    </section>

    <section id="day">

        <h3>Itinerary:</h3>

            <div class="day">
                <h4>DAY 01</h4>
                <ul>
                    <li>Meet at the airport</li>
                    <li>Visit Sapporo</li>
                    <li>Visit Shiroi Koibito Parl</li>
                    <li>Visit Tanukikoji Shopping Street </li>
                    <li>Visit Adori Park</li>
                    <li>Visit TV Tower</li>
                    <li>Transfer and check-in Hotel</li>
                    <li class="hotel">Hotel: Pipa no Yu Yurinkan</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 02</h4>
                <ul>
                    <li>Visit Asahikawa & Furano</li>
                    <li>Visit Asahikawa Zoo</li>
                    <li>Visit Ningle Terrace</li>
                    <li class="hotel">Hotel: Pipa no Yu Yurinkan</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 03</h4>
                <ul>
                    <li>Visit Otaru</li>
                    <li>Visit Funamizaka</li>
                    <li>Visit Kitachi Glass Otaru</li>
                    <li>Visit Tenguyama</li>
                    <li class="hotel">Hotel: Dai-ichi Takimotokan</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 04</h4>
                <ul>
                    <li>Visit Noboribetsu</li>
                    <li>Visit Jigokudani</li>
                    <li>Visit Noboribetsu Bear Park</li>
                    <li>Visit Lake Toya</li>
                    <li class="hotel">Hotel: Dai-ichi Takimotokan</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 05</h4>
                <ul>
                    <li>Visit Hakodate</li>
                    <li>Visit Hakodate Tropical Botanical Garden</li>
                    <li>Visit Hakodate Morning Market Square</li>
                    <li>Visit Hachiman Zaka Slope</li>
                    <li>Visit Mount Hakodate</li>
                    <li class="hotel">Hotel: Dai-ichi Takimotokan</li>
                </ul>
            </div>

            <div class="day">
                <h4>DAY 06</h4>
                <ul>
                    <li>Transfer to airport</li>
                </ul>
            </div>
    </tr>
</table>
</section>
<table>
    <tr>
        
       
            <ul><h3>Special Remarks</h3>
                    <li> Minimum of 10 participants</li>
                    <li> Arrival/Departure Airports: For arrivals at Narita (NRT) or Haneda (HND) airport.</li>
                    <li> Meal Requests: Vegetarian, halal or special meals can be arranged.</li>
                    <li> Subject to be change according to changes in cost of operating or number of participants.</li>
            </ul>
        
    </tr>
</table>


<table>
    <tr>
        
     
            <ol><h3>Terms and Conditions</h3>
                    <li> Non-refundable RM600 per person to reserve. Upon acknowledgement of deposit receipt, booking is considered confirmed and final. Cancellation can no longer be processed.</li>
                    <li> Full payment must be settled within 60 days before the departure date. As the deadline for payment is already stated. The company reserves the right to cancel the booking without prior notice. Deposit will be forfeited.</li>
                    <li> Visa is applied 90 days before the departure date. In case denied, 50% of the guaranteed deposit amount can be refunded 30 days before the departure date. Late request for refund leads to forfeited deposit.</li>
                    <li> Standard check-in time 12.00pm, Standard check-out time 12.00pm.</li>
            </ol>
     
    </tr>
</table>
</div>
     <footer>
    <div class="footer-section">
        <h1>Office Hours</h1>
        <p>Monday - Friday: 9 AM - 6 PM</p>
        <h1>Contact Us</h1>
        <p><a href="https://instagram.com/cherry._.pj?igshid=NGVhN2U2NjQ0Yg==">Cherly ></a>
        <a href="https://instagram.com/__dannyyy06?igshid=NGVhN2U2NjQ0Yg==">Danny ></a>
        <a href="https://instagram.com/yulin.tan__?igshid=NGVhN2U2NjQ0Yg==">Yu Lin ></a>
        <a href="https://instagram.com/yoong._.hui?igshid=NGVhN2U2NjQ0Yg==">Yoong Hui ></a>
        <a href="https://instagram.com/qian_torng?igshid=NGVhN2U2NjQ0Yg==">Qian Torng ></a>
        <a href="https://instagram.com/mittens.zip?igshid=NGVhN2U2NjQ0Yg==">Nafeez ></a></p>
    </div>
    <div class="footer-section">
        <h1>Package</h1>
        <p><a href="attraction.php">Attraction</a>
        <a href="package.php">Package</a></p>
    </div>
    <div class="footer-section">
        <h1>Links</h1>
        <p><a href="https://www.japan.go.jp/">JapanGov - The Government of Japan ></a>
        <a href="https://www.mofa.go.jp/">Ministry of Foreign Affairs of Japan ></a>
        <a href="https://www.mofa.go.jp/about/emb_cons/mofaserv.html">Japanese Embassies and Consulates websites ></a>
        <a href="https://www.japan.travel/en/my/">Japan National Tourism Organization Web Site ></a>
        <a href="https://www.studyinjapan.go.jp/en/">Study in JAPAN ></a></p>
    </div>
</footer>
<footer class="rights">&copy; 2023 Pheew. All rights reserved.</footer>
</body>
</html>
